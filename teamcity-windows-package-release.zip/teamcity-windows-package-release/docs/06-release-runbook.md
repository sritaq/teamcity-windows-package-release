# Release Runbook

Pre-release:
- Build successful
- Artifact available

Release:
- Deploy build triggered
- Package extracted

Post-release:
- Verify files
- Smoke test
