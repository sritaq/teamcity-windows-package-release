# Build & Package

The BUILD_PACKAGE configuration runs a PowerShell script
that creates a deployable ZIP package.

Script:
app/build.ps1
