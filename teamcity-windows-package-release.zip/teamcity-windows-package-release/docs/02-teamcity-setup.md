# TeamCity Setup

1. Create a new project in TeamCity
2. Add Git VCS root
3. Create BUILD_PACKAGE build configuration
4. Create DEPLOY_TO_WINDOWS build configuration

Add screenshots in docs/images/.
