# Artifacts

In BUILD_PACKAGE:
- Configure artifact paths:
  dist\app-package.zip

This makes the package available to downstream builds.
